// Minimal frontend logic for user panel (localStorage-based auth for demo)
const loginBtn = document.getElementById('loginBtn');
const regBtn = document.getElementById('regBtn');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const authForm = document.getElementById('authForm');
const authSubmit = document.getElementById('authSubmit');
const closeModal = document.getElementById('closeModal');
const unameEl = document.getElementById('uname');
const balEl = document.getElementById('bal');

let users = JSON.parse(localStorage.getItem('demo_users') || '[]');
let current = JSON.parse(localStorage.getItem('demo_current') || 'null');

function openModal(mode){
  modal.classList.remove('hidden');
  modalTitle.textContent = mode === 'login' ? 'Login' : 'Register';
  authForm.dataset.mode = mode;
}
loginBtn.addEventListener('click', ()=> openModal('login'));
regBtn.addEventListener('click', ()=> openModal('register'));
closeModal.addEventListener('click', ()=> modal.classList.add('hidden'));

authForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const mode = authForm.dataset.mode;
  const u = document.getElementById('username').value.trim();
  const p = document.getElementById('password').value.trim();
  if(mode === 'register'){
    if(users.find(x=>x.username===u)){ alert('Username taken'); return; }
    users.push({ username: u, password: p, balance: 0, vip:1 });
    localStorage.setItem('demo_users', JSON.stringify(users));
    alert('Registered. Now login.');
    modal.classList.add('hidden');
    return;
  }
  // login
  const found = users.find(x=>x.username===u && x.password===p);
  if(!found){ alert('Invalid credentials'); return; }
  current = found;
  localStorage.setItem('demo_current', JSON.stringify(current));
  updateUI();
  modal.classList.add('hidden');
});

function updateUI(){
  const cur = JSON.parse(localStorage.getItem('demo_current'));
  if(cur){
    unameEl.textContent = cur.username;
    balEl.textContent = 'USDT: ' + (cur.balance || 0).toFixed(2);
    loginBtn.style.display='none';
    regBtn.style.display='none';
  } else {
    unameEl.textContent = 'Guest';
    balEl.textContent = 'USDT: 0.00';
    loginBtn.style.display='inline-block';
    regBtn.style.display='inline-block';
  }
}

document.getElementById('deposit').addEventListener('click', ()=>{
  const cur = JSON.parse(localStorage.getItem('demo_current'));
  if(!cur){ openModal('login'); return; }
  // create a simple "notification" item in localStorage for admin demo
  const notes = JSON.parse(localStorage.getItem('demo_notes') || '[]');
  notes.unshift({ user: cur.username, message: 'Deposit request', created_at: new Date().toISOString() });
  localStorage.setItem('demo_notes', JSON.stringify(notes));
  alert('Deposit request sent to admin (demo).');
});

document.getElementById('withdraw').addEventListener('click', ()=>{
  const cur = JSON.parse(localStorage.getItem('demo_current'));
  if(!cur){ openModal('login'); return; }
  const notes = JSON.parse(localStorage.getItem('demo_notes') || '[]');
  notes.unshift({ user: cur.username, message: 'Withdraw request', created_at: new Date().toISOString() });
  localStorage.setItem('demo_notes', JSON.stringify(notes));
  alert('Withdraw request sent to admin (demo).');
});

updateUI();
