// admin frontend interactions (very simple)
const tokenKey = 'auth_token';
function showSection(name){
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  document.getElementById(name).classList.add('active');
  document.querySelectorAll('.sidebar button').forEach(b=>b.classList.remove('active'));
  document.querySelector('[data-section="'+name+'"]').classList.add('active');
}

document.querySelectorAll('.sidebar button').forEach(b=>{
  b.addEventListener('click', ()=> showSection(b.getAttribute('data-section')));
});

// fetch notifications
async function loadNotes(){
  const token = localStorage.getItem(tokenKey);
  if(!token) return;
  const res = await fetch('/api/admin/notifications', { headers: { Authorization: 'Bearer ' + token } });
  const data = await res.json();
  const container = document.getElementById('notes');
  container.innerHTML='';
  data.rows.forEach(r=>{
    const el = document.createElement('div'); el.className='note';
    el.innerHTML = '<b>'+ (r.username||'Unknown') +'</b>: '+ r.message + ' <br><small>'+ r.created_at +'</small> <br><button onclick="mark('+r.id+')">Mark seen</button>'
    container.appendChild(el);
  });
}
window.loadNotes = loadNotes;
async function mark(id){
  const token = localStorage.getItem(tokenKey);
  await fetch('/api/admin/notifications/'+id+'/seen', { method:'POST', headers:{ Authorization:'Bearer '+token }});
  loadNotes();
}

// logo upload form
document.getElementById('logoForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const token = localStorage.getItem(tokenKey);
  const file = e.target.logo.files[0];
  if(!file) return alert('Pick a file');
  const fd = new FormData();
  fd.append('logo', file);
  const res = await fetch('/api/admin/upload-logo', { method:'POST', headers:{ Authorization:'Bearer '+token }, body: fd });
  const data = await res.json();
  if(data.url){ document.getElementById('adminLogo').src = data.url; document.getElementById('saveMsg').textContent='Logo updated'; }
});

// load initial logo
async function loadLogo(){ const res = await fetch('/api/logo'); const j = await res.json(); if(j.url) document.getElementById('adminLogo').src = j.url; }
loadLogo();
loadNotes();
