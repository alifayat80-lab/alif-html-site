// very simple user interactions: create a notification on deposit/withdraw
async function postNotify(message){
  const token = localStorage.getItem('auth_token');
  if(!token){ alert('Login to create notification'); return; }
  await fetch('/api/notify', { method:'POST', headers: { 'Content-Type':'application/json', Authorization: 'Bearer '+ token }, body: JSON.stringify({ message }) });
  alert('Notification sent to admin');
}

document.getElementById('deposit').addEventListener('click', ()=> postNotify('Deposit request from user'));
document.getElementById('withdraw').addEventListener('click', ()=> postNotify('Withdraw request from user'));
