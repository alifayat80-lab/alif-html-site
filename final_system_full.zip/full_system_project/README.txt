
Simple Dashboard System (Express + SQLite)

How to run:
1. Extract the ZIP.
2. Run `npm install` in the project folder.
3. Run `node server.js` (or `npm start`). Server runs on port 3000 by default.
4. Open Admin panel: http://localhost:3000/public/admin/index.html
   - Default admin credentials: username=admin password=admin123
5. Open User panel: http://localhost:3000/public/user/index.html

Features included:
- User registration & login endpoints (/api/register, /api/login)
- Admin-only logo upload (/api/admin/upload-logo) -> saved to /uploads/logo.* and served.
- Notifications table saved in SQLite, admin can view and mark seen.
- Simple endpoints for profile, admin user updates.
- Logo persists because file is saved in uploads folder.
Note: This is a minimal, local development setup. For production you must change SECRET, use HTTPS, and secure file uploads.
