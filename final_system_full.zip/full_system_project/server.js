
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');

const SECRET = 'replace_this_secret_in_production';

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/public', express.static(path.join(__dirname, 'public')));

// setup DB
const dbFile = path.join(__dirname, 'data.sqlite');
const db = new sqlite3.Database(dbFile);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',
    balance REAL DEFAULT 0,
    vip INTEGER DEFAULT 1
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    message TEXT,
    type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    seen INTEGER DEFAULT 0
  )`);
  // create default admin if not exists
  db.get("SELECT id FROM users WHERE username = ?", ['admin'], (err,row)=>{
    if(!row){
      const hash = bcrypt.hashSync('admin123', 8);
      db.run("INSERT INTO users (username, password, role, balance, vip) VALUES (?, ?, 'admin', 0, 1)", ['admin', hash]);
      console.log('Default admin created: username=admin password=admin123');
    }
  });
});

// multer for logo upload (single file)
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: function (req, file, cb) {
    cb(null, 'logo' + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// auth helpers
function generateToken(user){ return jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '12h' }); }
function authMiddleware(req,res,next){
  const header = req.headers['authorization'];
  if(!header) return res.status(401).json({ error: 'No token' });
  const parts = header.split(' ');
  if(parts.length!==2) return res.status(401).json({ error: 'Bad token' });
  jwt.verify(parts[1], SECRET, (err, decoded)=>{
    if(err) return res.status(401).json({ error: 'Invalid token' });
    req.user = decoded; next();
  });
}

// routes
app.post('/api/register', (req,res)=>{
  const { username, password } = req.body;
  if(!username || !password) return res.status(400).json({ error: 'Missing fields' });
  const hash = bcrypt.hashSync(password, 8);
  db.run("INSERT INTO users (username,password) VALUES (?,?)", [username, hash], function(err){
    if(err) return res.status(400).json({ error: 'Username taken' });
    const user = { id: this.lastID, username };
    const token = generateToken(user);
    res.json({ success:true, token });
  });
});

app.post('/api/login', (req,res)=>{
  const { username, password } = req.body;
  if(!username || !password) return res.status(400).json({ error: 'Missing fields' });
  db.get("SELECT * FROM users WHERE username = ?", [username], (err,row)=>{
    if(err || !row) return res.status(400).json({ error: 'Invalid credentials' });
    if(!bcrypt.compareSync(password, row.password)) return res.status(400).json({ error: 'Invalid credentials' });
    const token = generateToken(row);
    res.json({ success:true, token, role: row.role });
  });
});

// upload logo (admin only)
app.post('/api/admin/upload-logo', authMiddleware, upload.single('logo'), (req,res)=>{
  if(req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  res.json({ success:true, url: '/uploads/' + req.file.filename });
});

// get current logo URL (if exists)
app.get('/api/logo', (req,res)=>{
  const files = fs.readdirSync(path.join(__dirname,'uploads')).filter(f=>f.startsWith('logo'));
  if(files.length) return res.json({ url: '/uploads/' + files[0] });
  return res.json({ url: null });
});

// create a notification (from user actions)
app.post('/api/notify', authMiddleware, (req,res)=>{
  const { message, type } = req.body;
  const userId = req.user.id;
  db.run("INSERT INTO notifications (user_id, message, type) VALUES (?, ?, ?)", [userId, message || 'Action', type || 'info'], function(err){
    if(err) return res.status(500).json({ error: 'DB error' });
    res.json({ success:true, id: this.lastID });
  });
});

// admin fetch notifications
app.get('/api/admin/notifications', authMiddleware, (req,res)=>{
  if(req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  db.all("SELECT n.*, u.username FROM notifications n LEFT JOIN users u ON u.id=n.user_id ORDER BY n.created_at DESC", [], (err,rows)=>{
    res.json({ rows });
  });
});

// admin mark seen
app.post('/api/admin/notifications/:id/seen', authMiddleware, (req,res)=>{
  if(req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  db.run("UPDATE notifications SET seen=1 WHERE id=?", [req.params.id], function(err){
    res.json({ success:true });
  });
});

// get user profile (protected)
app.get('/api/me', authMiddleware, (req,res)=>{
  db.get("SELECT id, username, role, balance, vip FROM users WHERE id = ?", [req.user.id], (err,row)=>{
    res.json({ user: row });
  });
});

// admin update user balance/vip (admin only)
app.post('/api/admin/users/:id/update', authMiddleware, (req,res)=>{
  if(req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const { balance, vip } = req.body;
  db.run("UPDATE users SET balance = ?, vip = ? WHERE id = ?", [balance || 0, vip || 1, req.params.id], function(err){
    res.json({ success:true });
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>{
  console.log('Server started on', PORT);
});
