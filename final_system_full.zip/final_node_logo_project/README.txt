
Improved Logo Upload Project (Express)

How to run (local):
1. Extract ZIP.
2. Run `npm install`.
3. Run `node server.js` (port 3000).
4. Open admin: http://localhost:3000/public/admin/index.html
   - default admin: admin / admin123
5. Open user: http://localhost:3000/public/user/index.html

Features:
- Admin login (demo) and logo upload (PNG/JPG/WEBP, max 2MB).
- Uploaded logo saved to /uploads/logo.* and served to both admin & user pages.
- Fixed products in admin (display only) and Buy buttons in user panel (demo alert).
- Basic rate limiting on /api routes and file validation.
Notes:
- This is a local/demo setup. For production harden secrets and use proper auth, HTTPS, and storage.
