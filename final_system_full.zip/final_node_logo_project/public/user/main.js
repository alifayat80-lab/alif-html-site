// user panel script: refresh logo on load
async function loadLogo(){ const res = await fetch('/api/logo'); const j = await res.json(); if(j.url) document.getElementById('logo').src = j.url; }
loadLogo();

document.querySelectorAll('.act').forEach(b=> b.addEventListener('click', ()=> alert('Product action (demo)')));