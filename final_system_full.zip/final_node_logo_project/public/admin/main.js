async function login(){
  const u = document.getElementById('username').value;
  const p = document.getElementById('password').value;
  const res = await fetch('/api/login', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ username: u, password: p }) });
  const j = await res.json();
  if(j.success){ localStorage.setItem('admin_token', j.token); document.getElementById('msg').textContent = 'Logged in'; loadLogo(); }
  else { alert('Login failed'); }
}
document.getElementById('loginBtn').addEventListener('click', login);

async function loadLogo(){
  const res = await fetch('/api/logo'); const j = await res.json();
  if(j.url) document.getElementById('adminLogo').src = j.url;
}
loadLogo();

document.getElementById('logoForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const token = localStorage.getItem('admin_token');
  if(!token) return alert('Login first');
  const file = document.getElementById('logoInput').files[0];
  if(!file) return alert('Pick an image');
  const fd = new FormData(); fd.append('logo', file);
  const res = await fetch('/api/admin/upload-logo', { method:'POST', headers: { Authorization: 'Bearer ' + token }, body: fd });
  const j = await res.json();
  if(j.url){ document.getElementById('adminLogo').src = j.url; document.getElementById('msg').textContent = 'Logo uploaded'; }
  else document.getElementById('msg').textContent = 'Upload failed';
});