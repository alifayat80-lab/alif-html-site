const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/public', express.static(path.join(__dirname, 'public')));

// simple rate limiter for auth/upload routes
const limiter = rateLimit({ windowMs: 60*1000, max: 30 });
app.use('/api/', limiter);

// ensure uploads dir exists
if(!fs.existsSync(path.join(__dirname,'uploads'))){
  fs.mkdirSync(path.join(__dirname,'uploads'));
}

// multer setup with file filter and size limit (2MB)
const storage = multer.diskStorage({
  destination: function(req, file, cb){ cb(null, path.join(__dirname, 'uploads')); },
  filename: function(req, file, cb){ cb(null, 'logo' + path.extname(file.originalname)); }
});
function fileFilter (req, file, cb) {
  const allowed = ['image/png','image/jpeg','image/webp'];
  if(!allowed.includes(file.mimetype)) return cb(new Error('Only PNG/JPG/WEBP allowed'), false);
  cb(null, true);
}
const upload = multer({ storage: storage, limits: { fileSize: 2*1024*1024 }, fileFilter: fileFilter });

// simple admin auth demo (in-memory, DO NOT use in production)
const ADMIN_USER = { username: 'admin', password: 'admin123' };

// login (very basic, returns a dummy token)
app.post('/api/login', (req,res)=>{
  const { username, password } = req.body;
  if(username === ADMIN_USER.username && password === ADMIN_USER.password){
    return res.json({ success:true, token: 'demo-admin-token' });
  }
  res.status(401).json({ error: 'Invalid credentials' });
});

// upload logo (requires token header Authorization: Bearer demo-admin-token)
app.post('/api/admin/upload-logo', upload.single('logo'), (req,res)=>{
  const auth = req.headers['authorization'] || '';
  if(auth !== 'Bearer demo-admin-token') return res.status(403).json({ error: 'Forbidden' });
  res.json({ success:true, url: '/uploads/' + req.file.filename });
});

// get logo URL
app.get('/api/logo', (req,res)=>{
  const files = fs.readdirSync(path.join(__dirname,'uploads')).filter(f=>f.startsWith('logo'));
  if(files.length) return res.json({ url: '/uploads/' + files[0] });
  return res.json({ url: null });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server running on port', PORT));
