// Simple interactions: VIP auto-rotate and logo upload preview
const vipEl = document.getElementById('vip');
let vip = 1;
setInterval(()=>{
  vip = vip >= 5 ? 1 : vip+1;
  vipEl.textContent = 'VIP ' + vip;
}, 5000);

// logo upload preview (click logo to change locally)
document.getElementById('logo').addEventListener('click', ()=>{
  const input = document.createElement('input');
  input.type='file'; input.accept='image/*';
  input.onchange = e => {
    const f = e.target.files[0]; if(!f) return;
    const r = new FileReader();
    r.onload = ev => document.getElementById('logo').src = ev.target.result;
    r.readAsDataURL(f);
  };
  input.click();
});